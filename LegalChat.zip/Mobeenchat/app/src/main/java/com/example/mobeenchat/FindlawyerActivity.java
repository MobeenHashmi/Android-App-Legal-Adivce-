package com.example.mobeenchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class FindlawyerActivity extends AppCompatActivity {

    Toolbar mToolbar;
    RecyclerView FindLawyerRecycle;
    DatabaseReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findlawyer);

        userRef = FirebaseDatabase.getInstance().getReference().child("Users");

        FindLawyerRecycle = findViewById(R.id.find_lawuer_Recycle);
        FindLawyerRecycle.setLayoutManager(new LinearLayoutManager(this));

        mToolbar = findViewById(R.id.find_lawuer_toolbar);
        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Find Lawyer");
    }

   @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerOptions<Contacts> options =
                new FirebaseRecyclerOptions.Builder<Contacts>()
                        .setQuery(userRef, Contacts.class)
                        .build();

        FirebaseRecyclerAdapter<Contacts, FindlawyerViewHolder> adapter = new FirebaseRecyclerAdapter<Contacts, FindlawyerViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull FindlawyerViewHolder holder, final int position, @NonNull Contacts model)
            {
                holder.username.setText(model.getName());
                holder.userstatus.setText(model.getStatus());
                Picasso.get().load(model.getPicture()).placeholder(R.drawable.profile_image).into(holder.smalllprofileimage);


                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        String visit_user_id=getRef(position).getKey();

                        Intent profileIntent = new Intent(FindlawyerActivity.this,ProfileActivity.class);
                        profileIntent.putExtra("vist_user_id", visit_user_id);

                        startActivity(profileIntent);

                    }
                });


            }

            @NonNull
            @Override
            public FindlawyerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.users_display_layout, parent, false);
                FindlawyerViewHolder viewHolder = new FindlawyerViewHolder(view);
                return viewHolder;
            }
        };
        FindLawyerRecycle.setAdapter(adapter);
        adapter.startListening();

    }

    public static class FindlawyerViewHolder extends RecyclerView.ViewHolder
    {
        TextView username , userstatus;
        CircleImageView smalllprofileimage;


        public FindlawyerViewHolder(@NonNull View itemView)
        {

            super(itemView);

            username= itemView.findViewById(R.id.user_name);
            userstatus= itemView.findViewById(R.id.user_status);
            smalllprofileimage = itemView.findViewById(R.id.user_icon_profile_image);
        }
    }
}
