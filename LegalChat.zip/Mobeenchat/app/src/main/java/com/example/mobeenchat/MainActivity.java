package com.example.mobeenchat;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity {

    private Toolbar mtoolbar;
    private ViewPager myViewpager;
    private TabLayout mytablayout;
    private TabAccessorAdapter mytabAccessorAdapter;
    private FirebaseUser currentUser;
    private FirebaseAuth mAuth;
    DatabaseReference Rootref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        Rootref = FirebaseDatabase.getInstance().getReference();
        currentUser = mAuth.getCurrentUser();



        mtoolbar = (Toolbar) findViewById(R.id.main_page_toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setTitle("Legal Advice");

        myViewpager = findViewById(R.id.main_tabs_paper);
        mytabAccessorAdapter = new TabAccessorAdapter(getSupportFragmentManager());
        myViewpager.setAdapter(mytabAccessorAdapter);

        mytablayout = findViewById(R.id.main_tabs);
        mytablayout.setupWithViewPager(myViewpager);

    }


    @Override
    protected void onStart() {
        super.onStart();
        if(currentUser == null)
        {
            SendUserTologinActivity();
        }
        else
            {
                VerifyUserExistence();
            }
    }

    private void VerifyUserExistence()
    {
        String currentuserID = mAuth.getCurrentUser().getUid();
        Rootref.child("Users").child(currentuserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if((dataSnapshot.child("name").exists()))
                {
                    Toast.makeText(MainActivity.this, "WELCOME", Toast.LENGTH_SHORT).show();
                }
                else
                    {
                        SendUserToSettingActivity();
                    }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
         super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.option_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
         super.onOptionsItemSelected(item);
         if(item.getItemId() == R.id.main_find_friends_option)
         {
             SendToFindLawyerActivity();

         }
        if(item.getItemId() == R.id.main_Create_Bar_Room_option)
        {
            RequestNewBarRoom();

        }
        if(item.getItemId() == R.id.main_logout_option){
            mAuth.signOut();
            SendUserTologinActivity();
        }
        if(item.getItemId() == R.id.main_settings_option){
        SendUserToSettingActivity();

        }
        if(item.getItemId() == R.id.main_My_Case_option)
        {
            SendToCaseFormActivity();

        }
        return true;

    }



    private void RequestNewBarRoom()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this, R.style.AlertDialog);
        builder.setTitle("ENTER BAR ROOM NAME :  ");

        final EditText BarRoomNameField = new EditText(MainActivity.this);


        BarRoomNameField.setHint("e.g Punjab Bar");
        builder.setView(BarRoomNameField);



        builder.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                String Barname = BarRoomNameField.getText().toString();


                if(TextUtils.isEmpty(Barname))
                {
                    Toast.makeText(MainActivity.this, "Please fill the Bar Name", Toast.LENGTH_SHORT).show();
                }
                else
                    {
                        CreateNewBarRoom(Barname);

                    }

            }
        });


        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.cancel();

            }
        });
        builder.show();
    }

    private void CreateNewBarRoom(final String barname)
    {
        Rootref.child("BarRooms").child(barname).setValue("").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task)
            {
                if(task.isSuccessful())
                {
                    Toast.makeText(MainActivity.this, barname +" Is Created in Database Firebase", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    private void SendUserTologinActivity() {
        Intent loginIntent = new Intent(MainActivity.this,LoginActivity.class);
        loginIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(loginIntent);
        finish();
    }
    private void SendUserToSettingActivity() {
        Intent settingIntent = new Intent(MainActivity.this,SettingsActivity.class);
        settingIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(settingIntent);
        finish();
    }

    private void SendToCaseFormActivity()
    {
        Intent myCaseIntenet = new Intent(MainActivity.this,MyCaseActivity.class);
        myCaseIntenet.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(myCaseIntenet);
        finish();
    }

    private void SendToFindLawyerActivity()
    {
        Intent FindlawyerIntenet = new Intent(MainActivity.this,FindlawyerActivity.class);
        startActivity(FindlawyerIntenet);

    }
}
