package com.example.mobeenchat;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import de.hdodenhof.circleimageview.CircleImageView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.net.URI;
import java.util.HashMap;

public class SettingsActivity extends AppCompatActivity {

    Button UpdateAccountSettings;
    EditText userName , userStatus;
    CircleImageView userProfileImage;
    String currentUserID;
    FirebaseAuth mAuth;
    DatabaseReference Rootref;

    StorageReference ProfileImageRef;

    static final int GALLERYPIC=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();
        Rootref = FirebaseDatabase.getInstance().getReference();
        ProfileImageRef = FirebaseStorage.getInstance().getReference().child("Profile Pictures");

        Intializefields();

        UpdateAccountSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Updateprofile();

            }
        });

        userProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,GALLERYPIC);
            }
        });


        RetriveUUserInfo();
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==GALLERYPIC && resultCode==RESULT_OK && data!=null)
        {
            Uri ImageUri = data.getData();
            CropImage.activity().setGuidelines(CropImageView.Guidelines.ON).setAspectRatio(1,1).start(this);
        }

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE)
        {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);

            if(resultCode == RESULT_OK)
            {
                Uri resultUri = result.getUri();
                StorageReference filePath = ProfileImageRef.child(currentUserID + ".jpg");


                filePath.putFile(resultUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                final Task<Uri> firebaseUri = taskSnapshot.getStorage().getDownloadUrl();
                                firebaseUri.addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        final String downloadUrl = uri.toString();

                                        Rootref.child("Users").child(currentUserID).child("picture")
                                                .setValue(downloadUrl)
                                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if(task.isSuccessful()){
                                                            Toast.makeText(SettingsActivity.this, "Image saved in database successfuly", Toast.LENGTH_SHORT).show();

                                                        }
                                                        else{
                                                            String message = task.getException().toString();
                                                            Toast.makeText(SettingsActivity.this, "Error: " + message,Toast.LENGTH_SHORT).show();


                                                        }

                                                    }
                                                });

                                    }
                                });

                            }
                        });

                /*StorageReference filepath = ProfileImageRef.child(currentUserID + ".jpg");

                filepath.putFile(resultUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task)
                    {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(SettingsActivity.this, "Updated Image", Toast.LENGTH_SHORT).show();

                            final String download_Url= task.getResult().getStorage().getDownloadUrl().toString();

                            Rootref.child("Users").child(currentUserID).child("picture").setValue(download_Url)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task)
                                        {
                                            if(task.isSuccessful())
                                            {
                                                Toast.makeText(SettingsActivity.this, "It is saved in DB", Toast.LENGTH_SHORT).show();

                                            }
                                            else
                                                {

                                                    Toast.makeText(SettingsActivity.this, "Error Sorry can't stire in db", Toast.LENGTH_SHORT).show();
                                                }

                                        }
                                    });

                        }
                        else
                            {
                                String meassage = task.getException().toString();

                                Toast.makeText(SettingsActivity.this, "Error : " + meassage, Toast.LENGTH_SHORT).show();
                            }

                    }
                });

*/
            }

        }
    }

    private void Updateprofile()
    {
        String setusername = userName.getText().toString();
        String setuserstatus = userStatus.getText().toString();


        if(TextUtils.isEmpty(setusername))
        {
            Toast.makeText(this, "Plesae fill the fields", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(setuserstatus))
        {
            Toast.makeText(this, "Plesae fill the fields", Toast.LENGTH_SHORT).show();
        }
        else
            {
                HashMap<String,String> profileMap = new HashMap<>();
                profileMap.put("uid", currentUserID);
                profileMap.put("name", setusername);
                profileMap.put("status", setuserstatus);

                Rootref.child("Users").child(currentUserID).setValue(profileMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task)
                    {
                        if(task.isSuccessful())
                        {
                            SendUserToMainActivity();
                            Toast.makeText(SettingsActivity.this, "Profile is update in FireBase Database", Toast.LENGTH_SHORT).show();
                        }
                        else
                            {
                                String message = task.getException().toString();
                                Toast.makeText(SettingsActivity.this, "Error :" + message, Toast.LENGTH_SHORT).show();
                            }

                    }
                });

            }
    }

    private void Intializefields()
    {
        UpdateAccountSettings = findViewById(R.id.update_button);
        userName = findViewById(R.id.set_user_name);
        userStatus = findViewById(R.id.set_profile_status);
        userProfileImage = findViewById(R.id.profile_image);
    }


    private void RetriveUUserInfo()
    {
        Rootref.child("Users").child(currentUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if((dataSnapshot.exists()) && (dataSnapshot.hasChild("name") && (dataSnapshot.hasChild("picture"))) )
                {
                    String retrivename = dataSnapshot.child("name").getValue().toString();
                    String retrivestatus = dataSnapshot.child("status").getValue().toString();
                    String retriveimage = dataSnapshot.child("picture").getValue().toString();




                    userName.setText(retrivename);
                    userStatus.setText(retrivestatus);
                    Picasso.get().load(retriveimage).into(userProfileImage);




                }
                else if ((dataSnapshot.exists()) && (dataSnapshot.hasChild("name")))
                {
                    String retrivename = dataSnapshot.child("name").getValue().toString();
                    String retrivestatus = dataSnapshot.child("status").getValue().toString();

                    userName.setText(retrivename);
                    userStatus.setText(retrivestatus);

                }
                else
                {
                    Toast.makeText(SettingsActivity.this, "Please Make the profile", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });
    }



    private void SendUserToMainActivity() {
        Intent MainIntent = new Intent(SettingsActivity.this,MainActivity.class);
        MainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(MainIntent);
        finish();
    }
}
