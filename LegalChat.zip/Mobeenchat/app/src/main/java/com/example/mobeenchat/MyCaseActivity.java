package com.example.mobeenchat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MyCaseActivity extends AppCompatActivity {

    Button Register;
    Spinner mspinner;
    TextView mCaseType;
    EditText ClientName, CaseNo, Date_of_Hering, caseTitle,  mProceedings;
    FirebaseAuth mAuth;
    DatabaseReference Rootref;
    String currentUserID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_case);

        mAuth = FirebaseAuth.getInstance();
        Rootref = FirebaseDatabase.getInstance().getReference();
        currentUserID = mAuth.getCurrentUser().getUid();


        IntializeFeilds();

Register.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        InsertDataintoDB();


    }
});

        mspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                if(parent.getItemAtPosition(position).equals("Case Type"))
                {

                }
                else
                    {
                        mCaseType.setText(parent.getSelectedItem().toString());
                    }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void InsertDataintoDB()
    {

        String clientname = ClientName.getText().toString();
        String caseno = CaseNo.getText().toString();
        String casetype = mCaseType.getText().toString();
        String date_of_hering = Date_of_Hering.getText().toString();
        String casetitle =  caseTitle.getText().toString();
        String proceedings = mProceedings.getText().toString();

        if(TextUtils.isEmpty(clientname))
        {
            Toast.makeText(this, "Please Enter the Feilds", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(caseno))
        {
            Toast.makeText(this, "Please Enter the Feilds", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(date_of_hering))
        {
            Toast.makeText(this, "Please Enter the Feilds", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(casetitle))
        {
            Toast.makeText(this, "Please Enter the Feilds", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(proceedings))
        {
            Toast.makeText(this, "Please Enter the Feilds", Toast.LENGTH_SHORT).show();
        }
        if(TextUtils.isEmpty(casetype))
        {
            Toast.makeText(this, "Please Enter the Feilds", Toast.LENGTH_SHORT).show();
        }

        else
            {

                SendUserToMainActivity();
                HashMap<String,String> MyCaseMap = new HashMap<>();
                MyCaseMap.put("uid", currentUserID);
                MyCaseMap.put("CientName", clientname);
                MyCaseMap.put("CientType", casetype);
                MyCaseMap.put("CaseNo", caseno);
                MyCaseMap.put("Hering Date", date_of_hering);
                MyCaseMap.put("CaseTitle", casetitle);
                MyCaseMap.put("Proceedings", proceedings);


                /*currentUserID = Rootref.push().getKey();*/
                String currentUserID = mAuth.getCurrentUser().getUid();
                String Code = caseTitle.getText().toString();


                Rootref.child("Users").child(currentUserID).child("Cases").child(Code).setValue(MyCaseMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            Toast.makeText(MyCaseActivity.this, "Data is Inserted", Toast.LENGTH_SHORT).show();
                        }
                        else
                            {
                                Toast.makeText(MyCaseActivity.this, "Error" , Toast.LENGTH_SHORT).show();
                            }
                    }
                });

            }

    }

    private void IntializeFeilds()
    {
        caseTitle = findViewById(R.id.Case_Title);
        Register = findViewById(R.id.MyyCase_Register_button);
        mCaseType = findViewById(R.id.Case_type);
        mspinner = findViewById(R.id.Spinner);
        ClientName = findViewById(R.id.Client_Name);
        CaseNo = findViewById(R.id.Case_No);
        Date_of_Hering = findViewById(R.id.Date_of_hering);
        mProceedings = findViewById(R.id.Proceedings);

        List<String> Categories = new ArrayList<>();
        Categories.add(0, "Case Type");
        Categories.add("Civil Case");
        Categories.add("Criminal Case");
        ArrayAdapter<String> dataAdapter;
        dataAdapter= new ArrayAdapter(this,android.R.layout.simple_spinner_item,Categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mspinner.setAdapter(dataAdapter);



    }

    private void SendUserToMainActivity() {
        Intent MyCaseIntent = new Intent(MyCaseActivity.this,MainActivity.class);
        MyCaseIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(MyCaseIntent);
        finish();
    }
}
