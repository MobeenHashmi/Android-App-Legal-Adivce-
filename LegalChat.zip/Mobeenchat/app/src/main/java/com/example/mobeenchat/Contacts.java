
package com.example.mobeenchat;

public class Contacts
{

String name, status, picture;

    public Contacts()
    {

    }


    public Contacts(String name, String status, String picture)
    {
        this.name = name;
        this.status = status;
        this.picture = picture;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

}

